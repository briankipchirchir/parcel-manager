// Code your solution in this file!
const companyName='Scuber'
let mostProfitableNeighborhood='Chelsea'
let companyCeo='Susan Smith'